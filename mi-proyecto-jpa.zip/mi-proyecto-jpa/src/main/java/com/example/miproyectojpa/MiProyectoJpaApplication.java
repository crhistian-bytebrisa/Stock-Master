package com.example.miproyectojpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiProyectoJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiProyectoJpaApplication.class, args);
	}

}
