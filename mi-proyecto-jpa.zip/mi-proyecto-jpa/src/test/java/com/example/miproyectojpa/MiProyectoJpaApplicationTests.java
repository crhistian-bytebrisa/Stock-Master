package com.example.miproyectojpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiProyectoJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
